# Intentionally minimal for stubs
