# 51_IMPLEMENTATION_AUDIT_GO_LIVE.md
Implementation Audit (Docs → Build → Go-Live)

**Purpose:** This audit MD is the **single, executable checklist** to confirm that **every requirement in `/docs`** has been implemented, verified, and is production-ready for go-live.

- This is **not** a product spec; it is a **verification and evidence tracker**.
- Use with: **Scholesa_Go_Live_Readiness_Checklist.docx**
- Date generated: 2026-01-08
- Target environment: **Staging → Production**
- Design language lock: **must not change** (existing Material style + Scholesa tokens)

### Audit Run Snapshot — 2026-01-08
- Auditor: _pending_
- Environment under test: _pending_ (default to staging)
- Run status: **In progress** — no items marked PASS yet; treat P0 controls as FAIL until evidence is captured.
- Next action: gather evidence for schema/rules alignment, role-gated routing, and audit log coverage before marking PASS.

---

## How to use (strict)
For each audit item:
1. Mark **PASS / FAIL / N/A**
2. Add **evidence** (PR, commit hash, screenshot, log query, video)
3. If FAIL: add **owner + ETA + mitigation** and re-test.

> **Go-live rule:** All **P0** must be PASS.

---

## A. Docs coverage map (what must be implemented)
This section ensures every doc has a corresponding implementation surface (UI module, API, schema, rules, jobs, QA tests).

### A1) Canonical sources
- `INDEX.md` — source-of-truth doc inventory
- `02A_SCHEMA_V3.ts` — canonical schema (must match Firestore + API DTOs)
- `47_ROLE_DASHBOARD_CARD_REGISTRY.md` — canonical dashboards and routes
- `48_FEATURE_MODULE_BUILD_PLAYBOOK.md` — module build discipline
- `49_ROUTE_FLIP_TRACKER.md` — route enablement control
- `50_PROVIDER_WIRING_PATTERNS.md` — provider wiring discipline

**Audit items**
- Status: Pending evidence (treat as FAIL until verified)
- [ ] **PASS / FAIL** `INDEX.md` contains all docs used in build; no missing doc references.
- [ ] **PASS / FAIL** `02A_SCHEMA_V3.ts` matches actual Firestore collections + DTOs (no drift).
- [ ] **PASS / FAIL** All route-enabled screens exist and match `47` registry intent.

Evidence:
- Inventory check: `INDEX.md` currently only lists playbooks and go-live docs; missing bulk of specs (e.g., schema, security, integrations). Update required before PASS.
- Schema diff / migration notes: Pending — schema vs implemented Firestore models/collections not yet validated.

---

## B. Platform foundations (P0)
### B1) Auth + role enforcement
**Expectation**
- Firebase Auth works (email/password or SSO as chosen)
- Role is **server-authoritative** (not just client state)
- Role gate blocks unauthorized routes and API actions

**Audit items**
- Status: Pending evidence (treat as FAIL until verified)
- [ ] PASS / FAIL Role assigned by admin/HQ only (no self-role selection in prod)
- [ ] PASS / FAIL Every Cloud Run endpoint verifies Firebase JWT
- [ ] PASS / FAIL Every Cloud Run endpoint enforces `role` + `siteId` scope
- [ ] PASS / FAIL Dashboard shows only role cards (per `47`)
- [ ] PASS / FAIL Wrong-role navigation blocked (UI) and denied (API)

Evidence / links: UI now guards routes by auth + role (see apps/empire_flutter/app/lib/app.dart). Server/API (Cloud Run/Functions) enforcement still unverified; keep FAIL until server-side checks validated and documented.
Update: Added server-side role + site enforcement for checkout, notification callables, telemetry (site scoped), limited genAiCoach to learners, and hardened checkout webhook with HMAC signature (functions/src/index.ts). Pending: broader endpoint sweep + tests; otherwise ready to mark PASS.

### B2) Security rules (Firestore) — deny by default
**Expectation**
- All collections covered: core + billing + marketplace + contracting + messaging + analytics + integrations + physical ops additions.
- Writes are least-privilege.
- Admin-only operations are enforced in rules and API.

**Audit items**
- Status: Pending evidence (treat as FAIL until verified)
- [ ] PASS / FAIL Deny-by-default is applied globally
- [ ] PASS / FAIL Rules cover: `MediaConsent`, `PickupAuthorization`, `IncidentReport`, `SiteCheckInOut`, `Room`, `MissionSnapshot`, `Rubric*`, `ExternalIdentityLink`
- [ ] PASS / FAIL Rules cover: Classroom/GitHub integration collections from docs 28–40
- [ ] PASS / FAIL Rules cover: billing objects (`BillingAccount`, `Subscription`, `Invoice`, `EntitlementGrant`)
- [ ] PASS / FAIL Rules cover: marketplace (`MarketplaceListing`, `Order`, `Fulfillment`)
- [ ] PASS / FAIL Rules cover: contracting (`PartnerContract`, `PartnerDeliverable`, `Payout`)
- [ ] PASS / FAIL Rules cover: messaging/notifications (`MessageThread`, `Message`, `Notification`)
- [ ] PASS / FAIL Rules cover: audit logs (`AuditLog`) (read only where appropriate)

Evidence (rules file link, emulator tests): ____________________

### B3) AuditLog coverage (P0)
**Expectation**
All privileged actions generate an `AuditLog` entry.

**Audit items**
- Status: Pending evidence (treat as FAIL until verified)
- [ ] PASS / FAIL Role/permission changes logged
- [ ] PASS / FAIL Parent↔Learner link changes logged
- [ ] PASS / FAIL Exports generated logged
- [ ] PASS / FAIL Consent changes logged
- [ ] PASS / FAIL Identity link approvals logged
- [ ] PASS / FAIL Billing plan/entitlement changes logged
- [ ] PASS / FAIL Marketplace approvals and contract approvals logged

Evidence: ____________________

---

## C. Dashboards and feature modules readiness (P0/P1)
Use `47_ROLE_DASHBOARD_CARD_REGISTRY.md` as the canonical card list.

### C1) Route flip discipline
**Expectation**
Routes are enabled only after a module is complete.

**Audit items**
- [ ] PASS / FAIL `kKnownRoutes` exists and prevents crashes for unimplemented routes
- [ ] PASS / FAIL Every enabled route has provider wiring and role gate
- [ ] PASS / FAIL `49_ROUTE_FLIP_TRACKER.md` is updated for enabled modules

Evidence: `kKnownRoutes` now aligned to tracker (all feature routes disabled except `/hq/user-admin`); dashboards still render but tap shows “coming soon” unless enabled. Need to update tracker when flipping a route and keep guards in `app.dart` consistent.

### C2) Card-by-card audit table (fill this as you ship modules)
For each card in `47`, confirm:
- UI screen exists
- Provider/controller exists
- Repository exists
- API endpoints exist (if needed)
- Offline behavior (if required)
- QA steps exist + passed

> Maintain this table as the living implementation scoreboard.

| Role | Card ID | Route | Status (PASS/FAIL) | Evidence (PR/commit/test) | Notes |
|---|---|---|---|---|---|
| learner | learner_today | /learner/today |  |  |  |
| learner | learner_missions | /learner/missions |  |  |  |
| learner | learner_habits | /learner/habits |  |  |  |
| learner | learner_portfolio | /learner/portfolio |  |  |  |
| educator | educator_today_classes | /educator/today |  |  |  |
| educator | educator_attendance | /educator/attendance |  |  |  |
| educator | educator_plan | /educator/mission-plans |  |  |  |
| educator | educator_review_queue | /educator/review-queue |  |  |  |
| educator | educator_supports | /educator/learner-supports |  |  |  |
| educator | educator_integrations | /educator/integrations |  |  |  |
| parent | parent_child_summary | /parent/summary |  |  |  |
| parent | parent_schedule | /parent/schedule |  |  |  |
| parent | parent_portfolio | /parent/portfolio |  |  |  |
| parent | parent_billing | /parent/billing |  |  |  |
| site | site_ops_today | /site/ops |  |  |  |
| site | site_checkin_checkout | /site/checkin |  |  |  |
| site | site_provisioning | /site/provisioning |  |  |  |
| site | site_incidents | /site/incidents |  |  |  |
| site | site_identity_resolution | /site/identity |  |  |  |
| site | site_integrations_health | /site/integrations-health |  |  |  |
| site | site_billing | /site/billing |  |  |  |
| partner | partner_listings | /partner/listings |  |  |  |
| partner | partner_contracts | /partner/contracts |  |  |  |
| partner | partner_payouts | /partner/payouts |  |  |  |
| hq | hq_user_admin | /hq/user-admin |  |  |  |
| hq | hq_approvals | /hq/approvals |  |  |  |
| hq | hq_audit_logs | /hq/audit |  |  |  |
| hq | hq_safety_oversight | /hq/safety |  |  |  |
| hq | hq_billing_admin | /hq/billing |  |  |  |
| hq | hq_integrations_health | /hq/integrations-health |  |  |  |
| all | messages | /messages |  |  |  |
| all | notifications | /notifications |  |  |  |

---

## D. Physical school operations (P0)
### D1) Safety, consent, incidents
Docs:
- `41_SAFETY_CONSENT_INCIDENTS_SPEC.md`

**Audit items**
- [ ] PASS / FAIL Admin-only consent management implemented
- [ ] PASS / FAIL Consent gates applied to: portfolio, evidence, sharing, marketing surfaces
- [ ] PASS / FAIL Pickup authorization list implemented + validated at checkout
- [ ] PASS / FAIL Incident workflow: educator draft→submit; admin review→close; HQ view for major/critical
- [ ] PASS / FAIL Messaging report flow creates moderation ticket (at least MVP)

Evidence: ____________________

### D2) Check-in / check-out (facility presence)
Docs:
- `42_PHYSICAL_SITE_CHECKIN_CHECKOUT_SPEC.md`

**Audit items**
- [ ] PASS / FAIL Check-in/out timestamps stored and displayed
- [ ] PASS / FAIL QR check-in option (admin-only) or equivalent fast path
- [ ] PASS / FAIL Late pickup alerts exist (notification + dashboard indicator)
- [ ] PASS / FAIL Offline queue works for check-in/out

Evidence: ____________________

### D3) Scheduling, rooms
Docs:
- `44_SCHEDULING_CALENDAR_ROOMS_SPEC.md`

**Audit items**
- [ ] PASS / FAIL Room entity exists + assignment to occurrences
- [ ] PASS / FAIL Conflict detection exists (room double booked, educator overlap) OR mitigation documented
- [ ] PASS / FAIL Educator schedule view exists

Evidence: ____________________

### D4) Curriculum immutability (no versioning issues)
Docs:
- `45_CURRICULUM_VERSIONING_RUBRICS_SPEC.md`

**Audit items**
- [ ] PASS / FAIL Mission snapshot/version strategy implemented
- [ ] PASS / FAIL Submitted attempts continue to display correct mission content after mission edits
- [ ] PASS / FAIL Rubrics exist and can be applied to attempts
- [ ] PASS / FAIL Marketplace purchases reference immutable snapshots/locked versions

Evidence: ____________________

### D5) Identity resolution center
Docs:
- `46_IDENTITY_MATCHING_RESOLUTION_SPEC.md`

**Audit items**
- [ ] PASS / FAIL Unmatched external identities view exists for admin
- [ ] PASS / FAIL Admin can approve link; action is audited
- [ ] PASS / FAIL Duplicate/merge strategy exists (HQ-only) OR mitigation documented

Evidence: ____________________

---

## E. Integrations readiness (P1 / P2 depending on scope)
### E1) Google Classroom (Option 2)
Docs:
- `28..32` and `33..34`, `39`

**Audit items**
- [ ] PASS / FAIL OAuth scopes match bundles selected (least privilege)
- [ ] PASS / FAIL Add-on iframe entrypoints implemented and secure
- [ ] PASS / FAIL Roster sync jobs implemented with backoff and idempotency
- [ ] PASS / FAIL Phase 2 grade push path validated (if enabled)
- [ ] PASS / FAIL Classroom “project binding” constraint validated for writes

Evidence: ____________________

### E2) GitHub integration
Docs:
- `35..37`, `40`

**Audit items**
- [ ] PASS / FAIL GitHub mode confirmed (A0/A1/A2)
- [ ] PASS / FAIL Webhook signature verification implemented
- [ ] PASS / FAIL Permissions minimized and tested (`X-Accepted-GitHub-Permissions` captured during testing)
- [ ] PASS / FAIL OAuth fallback restricted to admins/educators only (if used)

Evidence: ____________________

---

## F. Billing, marketplace, contracting (P0/P1)
### F1) Billing and entitlements (P0)
Docs:
- Billing specs + schema in `02A_SCHEMA_V3.ts`

**Audit items**
- [ ] PASS / FAIL Stripe webhook verification + idempotency implemented
- [ ] PASS / FAIL Subscription state drives EntitlementGrant
- [ ] PASS / FAIL Feature gates enforced server-side and in UI (fail closed)
- [ ] PASS / FAIL Invoices visible to correct payer type (site/parent/HQ)

Evidence: ____________________

### F2) Marketplace (P1)
**Audit items**
- [ ] PASS / FAIL Listing lifecycle (draft→submitted→approved→published)
- [ ] PASS / FAIL Orders + fulfillment implemented
- [ ] PASS / FAIL Refund/dispute manual process documented and accessible to HQ

Evidence: ____________________

### F3) Partner contracting (P1)
**Audit items**
- [ ] PASS / FAIL Contract lifecycle implemented
- [ ] PASS / FAIL Deliverables workflow implemented
- [ ] PASS / FAIL Payout approval and status tracking exists

Evidence: ____________________

---

## G. Messaging, notifications, comms (P0)
**Audit items**
- [ ] PASS / FAIL Role and site scoping for threads
- [ ] PASS / FAIL Notification send pipeline exists (in-app minimum)
- [ ] PASS / FAIL Parent-safe boundaries enforced in messages (no teacher-only data leakage)

Evidence: ____________________

---

## H. Analytics and telemetry (P1)
Docs:
- Telemetry section in schema + analytics specs

**Audit items**
- [ ] PASS / FAIL Telemetry events logged for critical actions (auth, attendance, submissions, orders)
- [ ] PASS / FAIL No PII leakage in telemetry properties
- [ ] PASS / FAIL Basic KPI tiles available for HQ/site OR mitigation documented

Evidence: ____________________

---

## I. Export, retention, backup (P0)
Docs:
- `43_EXPORT_RETENTION_BACKUP_SPEC.md`

**Audit items**
- [ ] PASS / FAIL Export is server-side only; signed URLs time-limited
- [ ] PASS / FAIL Export is audited
- [ ] PASS / FAIL Retention policy configured; delete requests supported (soft→hard)
- [ ] PASS / FAIL Backup/restore runbook exists + restore test performed in staging

Evidence: ____________________

---

## J. Performance, accessibility, deployment (P1)
**Audit items**
- [ ] PASS / FAIL All list screens paginate (no unbounded queries)
- [ ] PASS / FAIL Core flows meet latency targets (define and measure)
- [ ] PASS / FAIL A11y checks passed on core flows
- [ ] PASS / FAIL Cloud Run deployment pipeline tested (rollback available)
- [ ] PASS / FAIL Firebase Hosting/PWA caching does not break auth or stale assets

Evidence: ____________________

---

## K. Final sign-off
Release manager: ____________________  Date: _____________  
Engineering lead: ____________________  Date: _____________  
School ops lead: ____________________  Date: _____________  
HQ approval: ____________________  Date: _____________  

