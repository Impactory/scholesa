# 49_ROUTE_FLIP_TRACKER.md
Route Flip Tracker (enable routes only when modules are done)

How to use:
- Each route starts as DISABLED in `kKnownRoutes`.
- When module passes the “Done checklist” (docs/48), flip to ENABLED.
- Record the PR/commit that enabled it.

Legend:
- Status: DISABLED | IN_PROGRESS | ENABLED
- Owner: engineer or Codex batch label
- PR: link/id

---

## Shared
| Route | Card | Status | Owner | PR/Commit | Notes |
|---|---|---|---|---|---|
| /messages | messages | DISABLED | | | |
| /notifications | notifications | DISABLED | | | |

## Learner
| Route | Card | Status | Owner | PR/Commit | Notes |
|---|---|---|---|---|---|
| /learner/today | learner_today | DISABLED | | | |
| /learner/missions | learner_missions | DISABLED | | | |
| /learner/habits | learner_habits | DISABLED | | | |
| /learner/portfolio | learner_portfolio | DISABLED | | | |

## Educator
| Route | Card | Status | Owner | PR/Commit | Notes |
|---|---|---|---|---|---|
| /educator/today | educator_today_classes | DISABLED | | | |
| /educator/attendance | educator_attendance | DISABLED | | | |
| /educator/mission-plans | educator_plan | DISABLED | | | |
| /educator/review-queue | educator_review_queue | DISABLED | | | |
| /educator/learner-supports | educator_supports | DISABLED | | | |
| /educator/integrations | educator_integrations | DISABLED | | | |

## Parent
| Route | Card | Status | Owner | PR/Commit | Notes |
|---|---|---|---|---|---|
| /parent/summary | parent_child_summary | DISABLED | | | |
| /parent/schedule | parent_schedule | DISABLED | | | |
| /parent/portfolio | parent_portfolio | DISABLED | | | |
| /parent/billing | parent_billing | DISABLED | | | |

## Site
| Route | Card | Status | Owner | PR/Commit | Notes |
|---|---|---|---|---|---|
| /site/ops | site_ops_today | DISABLED | | | |
| /site/checkin | site_checkin_checkout | DISABLED | | | |
| /site/provisioning | site_provisioning | DISABLED | | | |
| /site/incidents | site_incidents | DISABLED | | | |
| /site/identity | site_identity_resolution | DISABLED | | | |
| /site/integrations-health | site_integrations_health | DISABLED | | | |
| /site/billing | site_billing | DISABLED | | | |

## Partner
| Route | Card | Status | Owner | PR/Commit | Notes |
|---|---|---|---|---|---|
| /partner/listings | partner_listings | DISABLED | | | |
| /partner/contracts | partner_contracts | DISABLED | | | |
| /partner/payouts | partner_payouts | DISABLED | | | |

## HQ
| Route | Card | Status | Owner | PR/Commit | Notes |
|---|---|---|---|---|---|
| /hq/user-admin | hq_user_admin | ENABLED | | | already wired |
| /hq/approvals | hq_approvals | DISABLED | | | |
| /hq/audit | hq_audit_logs | DISABLED | | | |
| /hq/safety | hq_safety_oversight | DISABLED | | | |
| /hq/billing | hq_billing_admin | DISABLED | | | |
| /hq/integrations-health | hq_integrations_health | DISABLED | | | |
